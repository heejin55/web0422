const cards = [
    {
        cimg: "https://product-image.kurly.com/hdims/resize/%5E%3E360x%3E468/cropcenter/360x468/quality/85/src/product/image/78ebd69e-1cc6-482c-b056-70f5da3f0022.jpg",
        cnum: 1,
        cmenu: "[KF365]양념 소불고기 1kg (냉장)",
        csale: "15%",
        cmoney: "18,691",
        cbtn: "담기"
    },
    {
        cimg: "https://product-image.kurly.com/hdims/resize/%5E%3E360x%3E468/cropcenter/360x468/quality/85/src/product/image/c056cd29-7df6-4b60-97c5-ea360da4707f.jpg?v=0418",
        cnum: 2,
        cmenu: "[압구정낙지]낙지 볶음 2종 (택1)",
        csale: "28%",
        cmoney: "7,100",
        cbtn: "담기"
    },
    {
        cimg: "https://product-image.kurly.com/hdims/resize/%5E%3E360x%3E468/cropcenter/360x468/quality/85/src/product/image/44442853-302e-499c-b323-914038150f10.jpg",
        cnum: 3,
        cmenu: "[선물세트]갤러리아 고메이494 재래구이...",
        csale: "15%",
        cmoney: "39,900",
        cbtn: "담기"
    },
    {
        cimg: "https://product-image.kurly.com/hdims/resize/%5E%3E360x%3E468/cropcenter/360x468/quality/85/src/product/image/09a0f576-c2cc-4d00-8ed4-c7d36c7b6967.jpg",
        cnum: 4,
        cmenu: "[조선호텔] 떡갈비 345g",
        csale: "",
        cmoney: "9,900",
        cbtn: "담기"
    },
    {
        cimg: "https://product-image.kurly.com/hdims/resize/%5E%3E360x%3E468/cropcenter/360x468/quality/85/src/product/image/59526651-9c34-4a39-9cd0-e30669a9ec4f.jpg",
        cnum: 5,
        cmenu: "[KF365]유명산지 고당도 사과 1.5kg",
        csale: "20%",
        cmoney: "19,900",
        cbtn: "담기"
    }
];