// 출력
const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);
root.render(<Ui />);

